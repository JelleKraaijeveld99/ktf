#ifndef AUDIO_CORE_H
#define AUDIO_CORE_H

#include <Audio.h>
#include <Wire.h>
#include <SPI.h>
#include <SD.h>

class AudioCore {
public:
    //constructor and destructor 
    AudioCore();
    ~AudioCore();
    //functions 
    void setupAudio(); //function for setting up the audio
    
    void playAudio(const char *filename); //function for playing an audio file 
    void playFoundAudio(const char* filename1, const char* filename2); //function for playing the found audio
    void audioProcess(int range); //function for processing everything together

    void setPlaybackSpeed(float speed);
    void setAmplitude(float amp);

    void setRange(int rng);

private:

    AudioPlaySdWav           playWav1; // Huidige audio
    AudioPlaySdWav           playWav2;  // Drumgeluid
    // AudioPlaySdWav           kysWav1;  // Toetsengeluid
    // AudioPlaySdWav           bssWav1;  // Basgeluid
    AudioOutputI2S           audioOutput;
 
    AudioConnection          patchCord1{playWav1, 0, audioOutput, 0};
    AudioConnection          patchCord2{playWav1, 1, audioOutput, 1};
    AudioConnection          patchCord3{playWav2, 0, audioOutput, 0};
    AudioConnection          patchCord4{playWav2, 1, audioOutput, 1};

    AudioControlSGTL5000     sgtl5000_1;
    // Use these with the Teensy Audio Shield
    #define SDCARD_CS_PIN    10
    #define SDCARD_MOSI_PIN  7   // Teensy 4 ignores this, uses pin 11
    #define SDCARD_SCK_PIN   14  // Teensy 4 ignores this, uses pin 13

    float amplitude;
    float playbackSpeed;
    int range;

};

#endif // AUDIO_CORE_H