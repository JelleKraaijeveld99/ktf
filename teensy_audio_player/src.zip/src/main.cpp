#include "audio_core.h"
#include "string.h"
#include <string>

using namespace std;

AudioCore audio;
// AudioCore audio2;

String filetemponame;
int range;
int beatIndicator;
const int size = 4;
String bpm100[] = {"DRM1.WAV", "DRM2.WAV", "DRM3.WAV", "DRM4.WAV"};
String bpm85[] = {"DRM5.WAV", "DRM6.WAV", "DRM7.WAV", "DRM8.WAV"};
String bpm70[] = {"DRM9.WAV", "DRM10.WAV", "DRM11.WAV", "DRM12.WAV"};
String wavFileList[size];

void setup()
{
    range = 20;
    beatIndicator = 0;
    audio.setupAudio();
    // audio2.setupAudio();
}

void loop()
{

    // if (range > 0 && range < 10)
    // {
    //     for (int i = 0; i < size; ++i)
    //     {
    //         wavFileList[i] = bpm100[i];
    //     }
    // }

    // if (range > 9 && range < 20)
    // {
    //     for (int i = 0; i < size; ++i)
    //     {
    //         wavFileList[i] = bpm85[i];
    //     }
    // }

    // if (range > 19 && range < 30)
    // {
    //     for (int i = 0; i < size; ++i)
    //     {
    //         wavFileList[i] = bpm70[i];
    //     }
    // }
    // const char* wavName = wavFileList[beatIndicator].c_str();
    // Serial.println("PLAYING: ");
    // Serial.println(wavName);
    // audio.playAudio(wavName);
    // beatIndicator++;
    // if (beatIndicator > 3){
    //     beatIndicator = 0;
    // }
    // Serial.println(beatIndicator);
    audio.playAudio("DRM3.WAV");
    // audio2.playAudio("DRM2.WAV");
    // audio.playFoundAudio("DRM2.WAV", "DRM3.WAV");

    delay(2000);

    // audio.playAudio("DRM4.WAV");
    // delay(5000);
}