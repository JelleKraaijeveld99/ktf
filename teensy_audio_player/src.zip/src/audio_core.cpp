#include "audio_core.h"

AudioCore::AudioCore() {
}

AudioCore::~AudioCore(){
    
}

void AudioCore::setupAudio() {
  Serial.begin(9600);
  AudioMemory(36);
  amplitude = 0.5;  
  sgtl5000_1.enable();
  sgtl5000_1.volume(amplitude);

  SPI.setMOSI(SDCARD_MOSI_PIN);
  SPI.setSCK(SDCARD_SCK_PIN);
  
  if (!(SD.begin(SDCARD_CS_PIN))) {
    while (1) {
      Serial.println("Unable to access the SD card");
      delay(500);
    }
  }
}

void AudioCore::playAudio(const char *filename) {
  Serial.print("Playing file: ");
  Serial.println(filename);

  playWav1.play(filename);
    // Extra: Controleer het maximale audiogeheugengebruik
  Serial.print("Max Audio Memory Usage: ");
  Serial.println(AudioMemoryUsageMax());

  Serial.println("playWav2 afspeelstatus: " + String(playWav2.isPlaying()));
  
  delay(25);

  while (playWav1.isPlaying()) {
    // Uncomment these lines if your audio shield
    // has the optional volume pot soldered
    // setAmplitude(0.1);
    // delay(1000);
    // setAmplitude(0.5);
    // delay(3000);
  }
}

void AudioCore::playFoundAudio(const char* filename1, const char* filename2){
 Serial.print("Playing files: ");
  
  // // // Controleer of bestanden bestaan voordat je ze probeert af te spelen
  // if (SD.exists(filename1)) {
  //   Serial.println(filename1);
  //   playWav1.play(filename1);
  // } else {
  //   Serial.println("File not found: " + String(filename1));
  // }

  // if (SD.exists(filename2)) {
  //   Serial.println(filename2);
  //   playWav2.play(filename2);
  // } else {
  //   Serial.println("File not found: " + String(filename2));
  // }

  // // Wacht tot het afspelen is voltooid
  // while (drmWav1.isPlaying() || kysWav1.isPlaying()) {
  //   delay(25);
  // }

}

void AudioCore::setAmplitude(float amp) {
    amplitude = amp;
    sgtl5000_1.volume(amplitude);
}

void AudioCore::setPlaybackSpeed(float speed) {
    playbackSpeed = speed;
}

void AudioCore::audioProcess(int range){
    setRange(range);
}

void AudioCore::setRange(int rng){ 
  range = rng;
}